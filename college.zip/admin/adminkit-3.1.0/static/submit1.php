<?php
require_once 'connection.php';
$errors = [];
$db = new Db(); // made instance of Db class

 $email = $_POST['email'] ?? ''; // coalescing  opreators
 $password = $_POST['password'] ?? '';

 if(!empty($email) && !empty($password)){
      $query = 'SELECT * from admin where email = "'.$email.'" AND password = "'.$password.'"';
      $totalRecords = $db->query($query);

      $total = isset($totalRecords['total']);
     if(!$total){
        $sql = "INSERT into admin (email,password) values('".$email."','".$password."')";
        $db->query($sql);
     }else{
        $errors['email'] = 'This email address is already used!';
     }
     header("Location: index.php");
 }
?>
