    <?php
require_once 'connection.php';
$errors = [];
$db = new Db(); // made instance of Db class

 $firstname = $_POST['firstname'] ?? ''; // coalescing  opreators
 $lastname = $_POST['lastname'] ?? '';
 $emailid = $_POST['emailid'] ?? '';
 $contact = $_POST['contact'] ?? '';
 $username = $_POST['username'] ?? '';
 $password = $_POST['password'] ?? '';

 if(!empty($firstname) && !empty($lastname) && !empty($emailid) && !empty($contact) && !empty($username) && !empty($password)){
 	 $query = 'SELECT count(id) as total from student where emailid = "'.$emailid.'" ';
 	 $totalRecords = $db->query($query);

 	 $total = isset($totalRecords['total']);
     if(!$total){
        $sql = "INSERT into student (firstname,lastname,emailid,contact,username,password,createdDate,status) values('".$firstname."','".$lastname."','".$emailid."','".$contact."','".$username."','".$password."',now(),'0')";
        $db->query($sql);
     }else{
        $errors['emailid'] = 'This email address is already used!';
     }
 
      if($totalRecords)
            {
                echo '<script> alert("Data added"); </script>';
                header("Location:users.php");
            }
        else
            {
                echo '<script> alert("Data Not added"); </script>';
            }
 }
?>
