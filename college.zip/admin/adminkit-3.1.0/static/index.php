<?php
 $connect = mysqli_connect('localhost', 'root', '', 'college');  
require_once 'connection.php';

$db = new Db();
$query = 'SELECT * from student ORDER BY ID DESC';
$records = $db->query($query);
 $result = mysqli_query($connect, $query) or die( mysqli_error($db));
error_reporting(0);
include("config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />
	<link rel="canonical" href="https://demo-basic.adminkit.io/" />
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedheader/3.1.7/css/fixedHeader.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">



	<title>AdminKit Demo - Bootstrap 5 Admin Template</title>
	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
    

    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/fixedheader/3.1.7/js/dataTables.fixedHeader.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/responsive.bootstrap.min.js"></script>



 <script src="datepicker/js/bootstrap-datepicker.min.js"></script>
  <script type="text/javascript" class="init">


        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#search thead th').each( function () {
                var title = $(this).text();
                $(this).html( ''+title+' <br><input type="text" class="filter" placeholder="Search '+title+'" />' );
            } );

            // DataTable
            var table = $('#search').DataTable({
                responsive: true,
fixedHeader: false,


                initComplete: function () {
                    // Apply the search
                    this.api().columns().every( function () {
                        var that = this;
                        $( 'input', this.header() ).on( 'keyup change clear', function () {
                            if ( that.search() !== this.value ) {
                                that
                                    .search( this.value )
                                    .draw();
                            }
                        } );
                    } );
                }
            });

            $('.filter').on('click', function(e){
                e.stopPropagation();
            });

           
            $("#search th.datepicker input").datepicker({
                format: "yyyy-mm-dd",

            });
        } );
  </script>

<style>
	#navbar {
  overflow: hidden;
  z-index: 99;

}


#navbar a:hover {
  background-color: #ddd;
 
}

#navbar a.active {
  background-color: #04AA6D;
  color: white;
}

.content {
  padding: 16px;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 60px;
}
.navbar-default{
  transition:500ms ease;
  background:transparent;
}
.navbar-default.scrolled{
  background:#000;
}
.whiteHam,.whiteHam:before,.whiteHam:after{
	background: #fff !important;
}

 .mode {
            float:right;
        }
        .change {
            cursor: pointer;
            border: 1px solid #555;
            border-radius: 40%;
            width: 20px;
            text-align: center;
            padding: 5px;
            margin-left: 8px;
        }
        .dark{
            background-color: #222;
            color: white;
        }
         .loader-container{
            width: 100%;
            height: 100vh;
            background-color: black;
            position: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader{
            width: 50px;
            height: 50px;
            border: 5px solid;
            color: #3498db;
            border-radius: 50%;
            border-top-color: transparent;
            animation: loader 1.2s linear infinite;
        }
        @keyframes loader{
            25%{
                color: #2ecc71;
            }
            50%{
                color: #f1c40f;
            }
            75%{
                color: #e74c3c;
            }
            to{
                transform: rotate(360deg);
            }
        }
</style>

</head>
<body>
     <div class="loader-container">
        <div class="loader"></div>
    </div>
	 
<div class="wrapper">
	<nav id="sidebar" class="sidebar js-sidebar">
		<div class="sidebar-content js-simplebar">
			<a class="sidebar-brand" href="index.html" target="_blank">
          		<span class="align-middle"><font style="font-size:20px;">AdminKit</font></span>
        </a>

				<ul class="sidebar-nav">
					<li class="sidebar-header mb-3">
						<font style="font-size:12px;">Pages</font>
					</li>

					<li class="sidebar-item active">
						<a class="sidebar-link" href="index.php">
              <i class="align-middle mb-2" data-feather="sliders"></i> <span class="align-middle"><font style="font-size:16px;">Dashboard</font></span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link mb-2" href="pages-profile.html">
              <i class="align-middle" data-feather="user"></i> <span class="align-middle"><font style="font-size:16px;">Profile</font></span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link mb-2" href="fee.php">
              <i class="align-middle" data-feather="book-open"></i> <span class="align-middle"><font style="font-size:16px;">FEE Structure</font></span>
            </a>

					<li class="sidebar-item">
						<a class="sidebar-link mb-2" href="users.php">
              <i class="align-middle" data-feather="book"></i> <span class="align-middle"><font style="font-size:16px;">Registered Users</font></span>
            </a>
					</li>
					<li class="sidebar-item">
                    <a class="sidebar-link mb-2" href="logout.php">
                    	<i class="align-middle" data-feather="log-out"></i> <span class="align-middle"><font style="font-size:16px;">Logout</font></span>
                    </a>
                </li>				
			</div>
		</nav>

	<div class="main">
		<div id="navbar">
	   <nav class="navbar navbar-expand navbar-light navbar-bg " >
				<a class="sidebar-toggle js-sidebar-toggle">
                   <i class="hamburger align-self-center"></i>
                </a>
                <div class="mode float-end">
        Dark mode:            
        <span class="change">OFF</span>
    </div>
		</nav>
	</div>

			<div class="content">
				<div class="container-fluid p-0">
					<h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1>
					<div class="row">
						<div class="col-12 col-lg-8 col-xxl-12 d-flex" style="margin-left:1%">
							<div class="card flex-fill">
								<div class="card-header">
									<h5 class="card-title mb-0"><font style="font-size:8px;">Latest Registered Students</font></h5>
								</div>
								<div class="table-responsive" id="employee_table">  						 
						        </div>
					        </div>
				         </div>
         <table  id="search" class="table table-striped table-bordered display  responsive nowrap" style="width: 100%">
            <thead>
                <tr >
                    <th ><strong> ID</font></strong></th>
                    <th ><strong><font style="font-size:15px"> First Name</font></strong></th>
                    <th><strong><font style="font-size:15px"> Last Name</font></strong></th>
                    <th class="datepicker"><strong><font style="font-size:15px"> Created Date</font></strong></th>
                    <th class="datepicker"><strong><font style="font-size:15px"> Modified Date</font></strong></th>
                </tr>
            </thead>
              <tbody>
                <?php

                $sql = "SELECT * FROM ".$SETTINGS["data_table"];

                if ($result = $mysqli->query($sql)) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td ><font style="font-size:15px"> <?php echo $row["id"]; ?></font></td>
                            <td><font style="font-size:15px"> <?php echo $row["firstname"]; ?></font></td>
                            <td><font style="font-size:15px"> <?php echo $row["lastname"]; ?></font></td>
                            <td><font style="font-size:15px"> <?php echo $row["createdDate"]; ?></font></td>
                            <td><font style="font-size:15px"> <?php echo $row["modifiedDate"]; ?></font></td>
                        </tr>
                    <?php }
                } else {
                ?>
                <tr><td colspan="5">No results found.</td>
                    <?php
                    }
                    ?></tr>
             </tbody>          
         </table>	
</div>
        

				</div>
			</main>

		
		</div>
	</div>

	<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

<script>
	$(document).ready(function(){
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 50) {
	    $(".navbar").css("background" , "#272833"); 
	    $(".hamburger").addClass('whiteHam');
	     $( ".mode" ).css( "color","white" );
	  }
 
	  else{
		  $(".navbar").css("background" , "white");  	
		  $(".hamburger").removeClass('whiteHam');
		   $( ".mode" ).css( "color","black" );
	  }
  })
})
</script>

<script>
        $( ".change" ).on("click", function() {
            if( $( ".main" ).hasClass( "dark" )) {
                $( ".main" ).removeClass( "dark" );
                $( ".change" ).text( "OFF" );
                 $( ".h3" ).css( "color","black" );
                 $( "td,th" ).css( "color","black" );
               
            } else {
                $( ".main" ).addClass( "dark" );
                 $( ".h3" ).css( "color","white" );
                 $( "td,th" ).css( "color","white" );
                $( ".change" ).text( "ON" );
              
            }
        });
    </script>

	<script src="js/app.js"></script>

	

</body>

</html>
<script>
        $(window).on("load",function(){ 
            $(".loader-container").fadeOut(500);
        });
    </script>