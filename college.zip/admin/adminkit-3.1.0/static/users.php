<?php
require_once 'connection.php';
$db = new Db();
$query = 'SELECT * from student ORDER BY id ASC';
$records = $db->query($query);
$id = $_GET['id'] ?? 0;
$status = $_GET['status'] ?? 0;
if($id){

	  $query = "update student set status=".$status.', modifiedDate=now() where id='.$id;
	  $db->query($query);
	  header('Location:'.$_SERVER['HTTP_REFERER'] ?? 'users.php');
	  exit();
}
// Set session
  session_start();
  if(isset($_POST['records-limit'])){
      $_SESSION['records-limit'] = $_POST['records-limit'];
  }
  
  $limit = isset($_SESSION['records-limit']) ? $_SESSION['records-limit'] : 5;
  $page = (isset($_GET['page']) && is_numeric($_GET['page']) ) ? $_GET['page'] : 1;
  $paginationStart = ($page - 1) * $limit;
  $records = $db->query("SELECT * FROM student ORDER BY id ASC LIMIT $paginationStart, $limit");
  // Get total records
  $sql = $db->query("SELECT count(id) AS id FROM student");
  $allRecords = $sql[0]['id'];
  
  // Calculate total pages
  $totalPages = ceil($allRecords / $limit);
  // Prev + Next
  $prev = $page - 1;
  $next = $page + 1;
  $page_limit = $limit;
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<link rel="canonical" href="https://demo-basic.adminkit.io/pages-blank.html" />

	<title>Blank Page | AdminKit Demo</title>

	<link href="css/app.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">


<style>
	.modal-dialog {
 
          width: 400px;
 
          height:950px !important;
 
        }
        .modal-content {
 
    /* 80% of window height */
 
    height: 60%;
 
    background-color:#BBD6EC;
 
}       
 
.modal-header {
 
    background-color: #337AB7;
 
    padding:16px 16px;
 
    color:#FFF;
 
    border-bottom:2px dashed #337AB7;
 
 }
    </style>
    <style>
#navbar {
  overflow: hidden;
   z-index: 99;
}

#navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}



.content {
  padding: 16px;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 60px;
}
.navbar-default{
  transition:500ms ease;
  background:transparent;
}
.navbar-default.scrolled{
  background:#000;
}
.whiteHam,.whiteHam:before,.whiteHam:after{
	background: #fff !important;
}

 .mode {
            float:right;
        }
        .change {
            cursor: pointer;
            border: 1px solid #555;
            border-radius: 40%;
            width: 20px;
            text-align: center;
            padding: 5px;
            margin-left: 8px;
        }
        .dark{
            background-color: #222;
            color: white;
        }
.loader-container{
            width: 100%;
            height: 100vh;
            background-color: black;
            position: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader{
            width: 50px;
            height: 50px;
            border: 5px solid;
            color: #3498db;
            border-radius: 50%;
            border-top-color: transparent;
            animation: loader 1.2s linear infinite;
        }
        @keyframes loader{
            25%{
                color: #2ecc71;
            }
            50%{
                color: #f1c40f;
            }
            75%{
                color: #e74c3c;
            }
            to{
                transform: rotate(360deg);
            }
        }
    </style>

</head>

<body>
    <div class="loader-container">
        <div class="loader"></div>
    </div>
	<div class="wrapper">

		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.html">
          <span class="align-middle">Admin</span>
        </a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Pages
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="index.php">
              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="pages-profile.html">
              <i class="align-middle" data-feather="user"></i> <span class="align-middle">Profile</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="fee.php">
              <i class="align-middle" data-feather="book-open"></i> <span class="align-middle">FEE Structure</span>
            </a>
					</li>

					<li class="sidebar-item active">
						<a class="sidebar-link" href="users.php">
              <i class="align-middle" data-feather="book"></i> <span class="align-middle">Registered Users/Students</span>
            </a>
					</li>
					<li class="sidebar-item">
                    <a class="sidebar-link" href="logout.php">
                    	<i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Logout</span>
                    </a>
                </li>
					
				</ul>

				
			</div>
		</nav>

		<div class="main">
			<div id="navbar">
			<nav class="navbar navbar-expand navbar-light navbar-bg  navbar-fixed-top">
				<a class="sidebar-toggle js-sidebar-toggle">
          <i class="hamburger align-self-center"></i>
        </a>
         <div class="mode float-end">
        Dark mode:            
        <span class="change">OFF</span>
    </div>
			</nav>
		</div>

	<div class="content">	
                  <div class="container  w-100">
                  	<div class="mb-3">
					
                  	<div class="card-header text-center w-100" >
					<h1 class="h3 ">Registered Users
					
						<a href="signup.php"><button type="submit" class=" btn btn-lg btn-primary mb-3 float-end " name="checkEmail">Add New User</button></a>
		            </div></h1>

        <!-- Select dropdown -->
        <div class="d-flex flex-row-reverse bd-highlight mb-3 justify-content-end">
            <form action="users.php" method="post" id="form1">
                <select name="records-limit" id="records-limit" class="custom-select">
                    <option disabled selected>Records Limit</option>
                    <?php foreach([5,7,10,12] as $limit) : ?>
                    <option
                        <?php if(isset($_SESSION['records-limit']) && $_SESSION['records-limit'] == $limit) echo 'selected'; ?>
                        value="<?= $limit; ?>">
                        <?= $limit; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
		            <div class="d-flex justify-content-center w-100">

					<div class="row">
						<div class="col-15">
								<div class="card-body">
									<table class="table table-bodered " style="height:100px;">
										<thead>
											<tr>
                                                <th>srNo</th>
												<th>ID</th>
												<th>First Name</th>
												<th>Last Name</th>
												<th>Email Id</th>
												<th>Username</th>
												<th>Status</th>
												<th>Edit</th>
                                                <th>Delete</th>
											</tr>
										</thead>
										
										<?php
                                        $j=1;
                                        $start=0;

                                        $page = $_GET['page'] ?? 1;
                                        $no = ($page-1)*$page_limit;
										if($records)
										{
											foreach($records as $row)
											{
                                                $no++;
												
										?>

											<tr id="user_info_<?= $row['id'] ?>">
                                                <td><?php echo $no; ?></td>
												<td><?php echo $row['id'];?></td>
												<td><?php echo  $row['firstname'];?></td>
												<td><?php echo  $row['lastname'];?></td>
												<td><?php echo  $row['emailid'];?></td>
												<td><?php echo  $row['username'];?></td>
                                                

												<td>
													<?php
													$status=$row['status'];
													if ($status == 1){
														?>
														<a class="btn btn-success btn1"  href="users.php?status=0&id=<?= $row['id'] ?>" >Active</a>

														<?php
													}
													else{
														?>
														<a class="btn btn-danger btn1" href="users.php?status=1&id=<?= $row['id'] ?>">Inactive</a>
														<?php
													}
													?></td>
												<td><button type="button" class="btn btn-primary editbtn" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" >Edit</button></td>	

												
                                                <td><input type="checkbox" name="id" class="delete_customer" value="<?php echo $row["id"]; ?>" /></td></tr>
											<?php
									  $j++; }
								}
								else {
									echo "no record found";
								}
   								?>
                              
   							</table>
                                 <div align="right" >
                                    <button type="button" name="btn_delete" id="btn_delete" class="btn btn-success ">Delete</button>
                                 </div>
        <nav aria-label="Page navigation example mt-5">
            <ul class="pagination justify-content-center">
                <li class="page-item <?php if($page <= 1){ echo 'disabled'; } ?>">
                    <a class="page-link" href="<?php if($page <= 1){ echo '#'; } else { echo "?page=" . $prev; } ?>">Previous</a>
                </li>
                <?php for($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?php if($page == $i) {echo 'active'; } ?>">
                    <a class="page-link" href="users.php?page=<?= $i; ?>"> <?= $i; ?> </a>
                </li>
                <?php endfor; ?>
                <li class="page-item <?php if($page >= $totalPages) { echo 'disabled'; } ?>">
                    <a class="page-link" href="<?php if($page >= $totalPages){ echo '#'; } else {echo "?page=". $next; } ?>">Next</a>
                </li>
            </ul>
        </nav>
    </div>
    <!-- jQuery + Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#records-limit').change(function () {
                $('#form1').submit();
            });

            $(document).on('click','.deletebtn',function (){
                value = $(this).data('attr');
                if (confirm('Are you sure want to delete the data?')){
                    $.ajax({
                        url: 'delete_record.php',
                        method: 'POST',
                        data: 'id='+value+'&name=test',
                        success: function(response) {
                            alert(response);
                            $('#user_info_'+value).remove();
                        },error: function (e){
                            alert(e.statusText);
                        }
                    })
                }    
            })
           
        });
    </script>
	
									<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="height:80%">
    <div class="modal-dialog row justify-content-center" role="document" align="center" style="height:100%">

        <div class="modal-content" align="left" style="height:100%">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> Edit Student Data </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" name="editbtn"></button>
            </div>
            <div class="mb-2">
            </div>
            <form action="" id="custForm" name="custForm" method="POST" >
            	
                <div class="form-group text-center mb-2 col-9 fw-bold" style="margin-left:3%">
                  <label >ID</label>
                  <input type="text" class="form-control "   value="" name="id" id="id" required>
                </div>
              
                <div class="form-group text-center mb-2 col-9 fw-bold"style="margin-left:3%">
                  <label >first Name</label>
                  <input type="text" class="form-control " placeholder="firstname" id="firstname" name="firstname" required>
                </div>
                <div class="form-group text-center mb-2 col-9 fw-bold"style="margin-left:3%">
                  <label >Last Name</label>
                  <input type="text" class="form-control " placeholder="lastname" value="" id="lastname" name="lastname" required>
                </div>
               
                <div class="form-group text-center md-2 col-9 fw-bold"style="margin-left:3%">
                  <label >Email-Id</label>
                  <input type="text" class="form-control " placeholder="emailid" id="emailid" value="" name="emailid" required>
                </div>
                 <div class="form-group text-center mb-3 col-9 fw-bold"style="margin-left:3%">
                  <label>Username</label>
                  <input type="text" class="form-control " placeholder="username" value="" id="username" name="username" required>
                </div>
                <div class="form-group mb-5 col-9 fw-bold"style="margin-left:3%">
                  
                    <button type="submit" id="submit" value="create" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- DELETE POP UP FORM (Bootstrap MODAL) -->
        <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"> Delete Student Data 
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

                        </button>
                    </div>
                    <form action="deletecode1.php" method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="delete_id" id="delete_id">
                            <h4> Do you want to Delete this Data ??</h4>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"> NO 
                            </button>
                            <button type="submit" name="deletedata" class="btn btn-primary"> Yes !! Delete it. 
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
				
<script>
    $(document).ready(function () {
        $('.editbtn').on('click', function () {
            $('#editmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();
                console.log(data);
                $('#id').val(data[1]);
                $('#firstname').val(data[2]);
                $('#lastname').val(data[3]);
                $('#emailid').val(data[4]);
                $('#username').val(data[5]);
            });
        $('#custForm').submit(function() {
         
        // ajax
        $.ajax({
            type:"POST",
            url: "update.php",
            data: $(this).serialize(), // get all form field value in 
            dataType: 'json',
            success: function(res){
             alert(response);
           }
        });

    });
        });
</script>
<script>
	$(document).ready(function(){
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 50) {
	    $(".navbar").css("background" , "#272833"); 
	    $(".hamburger").addClass('whiteHam');
	     $( ".mode" ).css( "color","white" );
	  }
 
	  else{
		  $(".navbar").css("background" , "white");  	
		  $(".hamburger").removeClass('whiteHam');
		   $( ".mode" ).css( "color","black" );
	  }
  })
})
</script>
<script>
window.onscroll = function() {myFunction()};
var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script> 

 <script>
        $( ".change" ).on("click", function() {
            if( $( ".main" ).hasClass( "dark" )) {
                $( ".main" ).removeClass( "dark" );
                $( ".change" ).text( "OFF" );
                 $( ".h3" ).css( "color","black" );
                 $( "td,th" ).css( "color","black" );
               
            } else {
                $( ".main" ).addClass( "dark" );
                 $( ".h3" ).css( "color","white" );
                 $( "td,th" ).css( "color","white" );
                $( ".change" ).text( "ON" );
              
            }
        });
    </script>
    <script>
$(document).ready(function(){
 
 $('#btn_delete').click(function(){
  
  if(confirm("Are you sure you want to delete this?"))
  {
   var id = [];
   
   $(':checkbox:checked').each(function(i){
    id[i] = $(this).val();
   });
   
   if(id.length === 0) //tell you if the array is empty
   {
    alert("Please Select atleast one checkbox");
   }
   else
   {
    $.ajax({
     url:'delete.php',
     method:'POST',
     data:{id:id},
     success:function()
     {
      for(var i=0; i<id.length; i++)
      {
       $('#user_info_'+id[i]+'').css('background-color', '#ccc');
       $('#user_info_'+id[i]+'').fadeOut('slow');
      }
     }
     
    });
   }
   
  }
  else
  {
   return false;
  }
 });
 
});
</script>

	<script src="js/app.js"></script>

</body>

</html>
<script>
        $(window).on("load",function(){ 
            $(".loader-container").fadeOut(500);
        });
    </script>