<?php  
 //sort.php  
 $connect = mysqli_connect("localhost", "root", "", "college");  
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  
 $query = "SELECT * FROM student ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query) or die( mysqli_error($connect));
  
 $output .= '  
     
 <div class="container-fluid p-0">
 <table class="table table-hover my-0">  
      <tr>  
           <th><a class="column_sort" id="firstname" data-order="'.$order.'" href="#">Name</a></th>  
           <th><a class="column_sort" id="createdDate" data-order="'.$order.'" href="#">Created Date</a></th>  
           <th><a class="column_sort" id="modifiedDate" data-order="'.$order.'" href="#">Modified Date</a></th>  
           <th><a class="column_sort" id="status" data-order="'.$order.'" href="#">Status</a></th>  
           <th><a class="column_sort" id="emailid" data-order="'.$order.'" href="#">Email Id</a></th>  
      </tr>  
      </DIV>
 ';  
 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '                                             
      <tr>  
           <td>' . $row["firstname"] . '</td>  
           <td>' . $row["createdDate"] . '</td>  
           <td>' . $row["modifiedDate"] . '</td>  
           <td>' . $row["status"] . '</td>  
           <td>' . $row["emailid"] . '</td>  
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>  