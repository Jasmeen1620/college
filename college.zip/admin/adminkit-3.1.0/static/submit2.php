<?php

if(count($_POST)>0)
{    
     include 'mydbCon.php';
     
     $ID = $_POST['ID'];
     $courses = $_POST['courses'];
     $fees = $_POST['fees'];
    
    
 
      $query = "INSERT INTO fees (ID,courses,fees)
      VALUES ('$ID','$courses','$fees')"; // insert data into database

    

    $res = mysqli_query($dbCon, $query);

    if($res) {

     echo json_encode($res);

    } else {

     echo "Error: " . $sql . "" . mysqli_error($dbCon);

    }

}

?>