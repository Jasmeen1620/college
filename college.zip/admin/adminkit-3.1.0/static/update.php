<?php

if(count($_POST)>0)
{    
     include 'mydbCon.php';
     
     $firstname = $_POST['firstname'];
     $lastname = $_POST['lastname'];
     $emailid = $_POST['emailid'];
     $contact = $_POST['contact'];
     $username = $_POST['username'];

     if(empty($_POST['id'])){
 
      $query = "INSERT INTO student (firstname,lastname,emailid,contact,username)
      VALUES ('$firstname','$lastname','$emailid','$contact','$username')"; // insert data into database

     }else{
       $query = "UPDATE student set id='" . $_POST['id'] . "', firstname='" . $_POST['firstname'] . "', lastname='" . $_POST['lastname'] . "', emailid='" . $_POST['emailid'] . "', contact='" . $_POST['contact'] . "', username='" . $_POST['username'] . "' WHERE id='" . $_POST['id'] . "'"; // update form data from the database
     }

    $res = mysqli_query($dbCon, $query);

    if($res) {

     echo json_encode($res);

    } else {

     echo "Error: " . $sql . "" . mysqli_error($dbCon);

    }

}

?>