<?php
require_once 'connection.php';
$db = new Db();
$query = 'SELECT * from fees';
$records = $db->query($query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/pages-profile.html" />

	<title>Profile | AdminKit Demo</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <style>
#navbar {
  overflow: hidden;
  background-color: #333;
  z-index: 99;
}

#navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}



.content {
  padding: 16px;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 60px;
}
.navbar-default{
  transition:500ms ease;
  background:transparent;
}
.navbar-default.scrolled{
  background:#000;
}
.whiteHam,.whiteHam:before,.whiteHam:after{
    background: #fff !important;
}

 .mode {
            float:right;
        }
        .change {
            cursor: pointer;
            border: 1px solid #555;
            border-radius: 40%;
            width: 20px;
            text-align: center;
            padding: 5px;
            margin-left: 8px;
        }
        .dark{
            background-color: #222;
            color: white;
        }
        .loader-container{
            width: 100%;
            height: 100vh;
            background-color: black;
            position: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader{
            width: 50px;
            height: 50px;
            border: 5px solid;
            color: #3498db;
            border-radius: 50%;
            border-top-color: transparent;
            animation: loader 1.2s linear infinite;
        }
        @keyframes loader{
            25%{
                color: #2ecc71;
            }
            50%{
                color: #f1c40f;
            }
            75%{
                color: #e74c3c;
            }
            to{
                transform: rotate(360deg);
            }
        }

</style>
<style>
	.modal-dialog {
 
          width: 400px;
 
          height:800px !important;
 
        }
        .modal-content {
 
    /* 80% of window height */
 
    height: 60%;
 
    background-color:#BBD6EC;
 
}       
 
.modal-header {
 
    background-color: #337AB7;
 
    padding:16px 16px;
 
    color:#FFF;
 
    border-bottom:2px dashed #337AB7;
 
 }
    </style>
</head>

<body>
    <div class="loader-container">
        <div class="loader"></div>
    </div>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.php">
          <span class="align-middle">Admin</span>
        </a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Pages
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="index.php">
              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
            </a>
					</li>

					<li class="sidebar-item ">
						<a class="sidebar-link" href="pages-profile.html">
              <i class="align-middle" data-feather="user"></i> <span class="align-middle">Profile</span>
            </a>
					</li>

					<li class="sidebar-item active">
						<a class="sidebar-link" href="fee.php">
              <i class="align-middle" data-feather="book-open"></i> <span class="align-middle">Fee Structure</span>
            </a>
					</li>
				

					<li class="sidebar-item">
						<a class="sidebar-link" href="users.php">
              <i class="align-middle" data-feather="book"></i> <span class="align-middle">Registered Users/students</span>
            </a>
					</li>
					<li class="sidebar-item">
                    <a class="sidebar-link" href="logout.php">
                    	<i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Logout</span>
                    </a>
                </li>

					
				</ul>

				
			</div>
		</nav>

	<div class="main">
        <div id="navbar">
		   <nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle js-sidebar-toggle">
                   <i class="hamburger align-self-center"></i>
               </a>
              <div class="mode float-end">
               Dark mode:            
               <span class="change">OFF</span>
              </div>
           </nav>
       </div>
			<main class="content">
				<div class="container-fluid p-0">

					<div class="mb-3">
						
                  	<div class="card-header">
						<h1 class="h3 d-inline align-middle">Fee Structure</h1>
                 <td><button type="button" class="btn btn-primary addbtn float-end" data-bs-toggle="modal" data-bs-target="addmodal" data-bs-whatever="@mdo">Add New Data</button></td>
		            </div></h1>


                    <div class="card-body">
									<table class="table table-bodered" style="width:100% " cellspacing="100px">	
											<tr>
												<th style="padding:5px">ID</th>
												<th>Courses</th>
												<th>FEES</th>
												<th>EDIT</th>
												<th>DELETE</th>
											</tr>
												<?php
										if($records)
										{
											foreach($records as $row)
											{
												
										?>
											<tr id="user_info_<?= $row['ID'] ?>">
												<td style="padding:5px"><?php echo $row['ID'];?></td>
												<td><?php echo $row['courses'];?></td>
												<td><?php echo $row['fees'];?></td>
												<td><button type="button" class="btn btn-primary btn-edit" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">EDIT</button></td>
												<td><button type="button" class="btn btn-danger deletebtn" data-attr="<?= $row['ID'] ?>" data-bs-target="deletemodal" data-bs-whatever="@mdo">Delete</button></td>
											</tr>		
                                <?php
									}
								}
								else {
									echo "no record found";
								}
								?>



<!--  Add POP UP -->
								<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ">
        <h5 class="modal-title " id="exampleModalLabel" style="margin-left:40%">ADD DATA</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
            <form action="" id="addform" name="addform" method="POST" >
            	 <div class="modal-body"  style="width: 75%;text-align: center;" ></div>
                <div class="row">
                <div class="form-group text-center mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label >ID</label>
                  <input type="text" class="form-control text-center"   value="" id="ID1" name="ID"  required>
                </div></div>
                <div class="row">
                <div class="form-group mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label style="margin-left:42%">COURSE</label>
                  <input type="text" class="form-control text-center"  name="courses" id="courses1"  required>
                </div></div>
                <div class="row">
                <div class="form-group mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label style="margin-left:45%">FEES</label>
                  <input type="text" class="form-control text-center" name="fees"  id="fees1"  required>
                </div></div>
            
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         <button type="submit" name="insertdata" class="btn btn-primary">Add</button>
      </div>
            </form>
      </div>
      
    </div>
  </div>
</div>

<!--  Update POP UP -->
								<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ">
        <h5 class="modal-title " id="exampleModalLabel" style="margin-left:40%">EDIT DATA</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
            <form action="" id="custForm" name="custForm" method="POST" >
            	 <div class="modal-body"  style="width: 75%;text-align: center;" ></div>
                <div class="row">
                <div class="form-group text-center mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label >ID</label>
                  <input type="text" class="form-control text-center"   value="" id="ID" name="ID"  required>
                </div></div>
                <div class="row">
                <div class="form-group mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label style="margin-left:42%">COURSE</label>
                  <input type="text" class="form-control text-center"  name="courses" id="courses"  required>
                </div></div>
                <div class="row">
                <div class="form-group mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label style="margin-left:45%">FEES</label>
                  <input type="text" class="form-control text-center" name="fees"  id="fees"  required>
                </div></div>
            
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         <button type="submit" name="updatedata" class="btn btn-primary">Update</button>
      </div>
            </form>
      </div>
      
    </div>
  </div>
</div>

<!-- DELETE POP UP FORM (Bootstrap MODAL) -->
        <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"> Delete Student Data 
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

                        </button>
                    </div>
                    <form action="deletecode.php" method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="delete_id" id="delete_id">
                            <h4> Do you want to Delete this Data ??</h4>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"> NO 
                            </button>
                            <button type="submit" name="deletedata" class="btn btn-primary"> Yes !! Delete it. 
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
						<script>
    $(document).ready(function () {
        $(document).on('click','.deletebtn',function (){
                value = $(this).data('attr');
                if (confirm('Are you sure want to delete the data?')){
                    $.ajax({
                        url: 'delete_record1.php',
                        method: 'POST',
                        data: 'ID='+value+'&name=test',
                        success: function(response) {
                            alert(response);
                            $('#user_info_'+value).fadeOut('slow');
                           
                        },error: function (e){
                            alert(e.statusText);
                        }
                    })
                }    
            })
           
        });
</script>
<script>
    $(document).ready(function () {
        $('.editbtn').on('click', function () {
            $('#exampleModal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();
                console.log(data);
                $('#ID').val(data[0]);
                $('#courses').val(data[1]);
                $('#fees').val(data[2]);
               
            });
         $('#custForm').submit(function() {
         
        // ajax
        $.ajax({
            type:"POST",
            url: "update1.php",
            data: $(this).serialize(), // get all form field value in 
            dataType: 'json',
            success: function(res){
             window.location.reload();
           }
        });

    });
        });
</script>
<script>
    $(document).ready(function () {
        $('.addbtn').on('click', function () {
            $('#addModal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();
                console.log(data);
                $('#ID1').val(data[0]);
                $('#courses1').val(data[1]);
                $('#fees1').val(data[2]);
               
            });
        $('#addform').submit(function() {
         
        // ajax
        $.ajax({
            type:"POST",
            url: "submit2.php",
            data: $(this).serialize(), // get all form field value in 
            dataType: 'json',
            success: function(res){
             window.location.reload();
           }
        });

    });
        });
</script>



		</div>
	</div>

	<script src="js/app.js"></script>

    <script>
window.onscroll = function() {myFunction()};
var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script> 

 <script>
        $( ".change" ).on("click", function() {
            if( $( ".main" ).hasClass( "dark" )) {
                $( ".main" ).removeClass( "dark" );
                $( ".change" ).text( "OFF" );
                 $( ".h3" ).css( "color","black" );
                 $( "td,th" ).css( "color","black" );
               
            } else {
                $( ".main" ).addClass( "dark" );
                 $( ".h3" ).css( "color","white" );
                 $( "td,th" ).css( "color","white" );
                $( ".change" ).text( "ON" );
              
            }
        });
    </script>
    <script>
    $(document).ready(function(){
  $(window).scroll(function(){
    var scroll = $(window).scrollTop();
      if (scroll > 50) {
        $(".navbar").css("background" , "#272833"); 
        $(".hamburger").addClass('whiteHam');
         $( ".mode" ).css( "color","white" );
      }
 
      else{
          $(".navbar").css("background" , "white");     
          $(".hamburger").removeClass('whiteHam');
           $( ".mode" ).css( "color","black" );
      }
  })
})
</script>

</body>

</html>			
<script>
        $(window).on("load",function(){ 
            $(".loader-container").fadeOut(500);
        });
    </script>		

<!--       <script type="text/javascript">
    $("form").submit(function(e) {
      e.preventDefault();
      var name=$("input[name='name']").val();
      var email=$("input[name='email']").val();

       $(".data-table tbody").append("<tr data-name='"+name+"' data-email='"+email+"'><td>"+name+"</td><td>"+email+"</td><td><button class='btn btn-danger btn-lg btn-delete mr-3' type='button'>Delete</button><button class='btn btn-info btn-lg btn-edit' type='button'>Edit</button></td></tr>");

       $("input[name='']").val("");
    });

    $('body').on('click','.btn-delete',function() {
      $(this).parents('tr').remove();
    });

    $('body').on('click','.btn-edit',function() {
      var name=$(this).parents('tr').attr('data-name');
      var email=$(this).parents('tr').attr('data-email');

      $(this).parents('tr').find('td:eq(0)').html("<input name='edit_text' value='"+name+"'>");
      $(this).parents('tr').find('td:eq(1)').html("<input name='edit_email' value='"+email+"'>");

      $(this).parents('tr').find('td:eq(2)').prepend("<button type='button' class='btn btn-info btn-lg btn-update mr-3'>Update</button>");
      $(this).hide()
    });

    $('body').on('click','.btn-update',function() {
      var name=$(this).parents('tr').find("input[name='edit_text']").val();
      var email=$(this).parents('tr').find("input[name='edit_email']").val();

      $(this).parents('tr').find('td:eq(0)').text(name);
      $(this).parents('tr').find('td:eq(1)').text(email);

      $(this).parents('tr').attr('data-name',name);
      $(this).parents('tr').attr('data-email',email);

      $(this).parents('tr').find('.btn-edit').show();
      $(this).parents('tr').find('.btn-update').remove();


    })

   </script>-->
