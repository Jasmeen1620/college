<?php
//delete.php
$connect = mysqli_connect("localhost", "root", "", "college");
if(isset($_POST["id"]))
{
 foreach($_POST["id"] as $id)
 {
  $query = "DELETE FROM student WHERE id = '".$id."'";
  mysqli_query($connect, $query);
 }
}
?>