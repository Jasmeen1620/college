<?php

//fetch_data.php
require_once 'connection.php';

$connect = new PDO("mysql:host=localhost;dbname=college", "root", "");

$method = $_SERVER['REQUEST_METHOD'];

if($method == 'GET')
{
 $data = array(
  ':firstname'   => "%" . $_GET['firstname'] . "%",
  ':lastname'   => "%" . $_GET['lastname'] . "%",
  ':emailid'     => "%" . $_GET['emailid'] . "%",
  ':username'    => "%" . $_GET['username'] . "%"
 );
 $query = "SELECT * FROM student WHERE firstname LIKE :firstname AND lastname LIKE :lastname AND emailid LIKE :emailid AND username LIKE :username ORDER BY firstname ASC";

 $statement = $connect->prepare($query);
 $statement->execute($data);
 $result = $statement->fetchAll();
 foreach($result as $row)
 {
  $output[] = array(
   'id'    => $row['id'],   
   'firstname'  => $row['firstname'],
   'lastname'   => $row['lastname'],
   'emailid'    => $row['emailid'],
   'username'   => $row['username']
  );
 }
 header("Content-Type: application/json");
 echo json_encode($output);
}

if($method == "POST")
{
 $data = array(
  ':firstname'  => $_POST['firstname'],
  ':lastname'  => $_POST["lastname"],
  ':emailid'    => $_POST["emailid"],
  ':username'   => $_POST["username"]
 );

 $query = "INSERT INTO student (firstname, lastname, emailid, username) VALUES (:firstname, :lastname, :emailid, :username)";
 $statement = $connect->prepare($query);
 $statement->execute($data);
}

if($method == 'PUT')
{
 parse_str(file_get_contents("php://input"), $_PUT);
 $data = array(
  ':id'   => $_PUT['id'],
  ':firstname' => $_PUT['firstname'],
  ':lastname' => $_PUT['lastname'],
  ':emailid'   => $_PUT['emailid'],
  ':username'  => $_PUT['username']
 );
 $query = "
 UPDATE student 
 SET firstname = :firstname, 
 lastname = :lastname, 
 emailid = :emailid, 
 username = :username 
 WHERE id = :id
 ";
 $statement = $connect->prepare($query);
 $statement->execute($data);
}

if($method == 'DELETE')
{
 parse_str(file_get_contents("php://input"), $_DELETE);
 $query = "DELETE FROM student WHERE id = '".$_DELETE["id"]."'";
 $statement = $connect->prepare($query);
 $statement->execute();
}

?>
