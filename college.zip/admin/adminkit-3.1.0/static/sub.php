<!DOCTYPE html>
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script>
   
    function add(){
        $('#value').val(parseInt($('#value').val())+1);  
        }      
     function sub(){
        $('#value').val(parseInt($('#value').val())-1);
    }
 
 

</script>
</head>
<body>
  <div class="container">
    <div class="row">
 <div class="col-lg-12">
 <label for="qty">Quntity:</label>
 </div>
 </div>
 <div class="row">
 <div class="col-lg-12">
 <button id="minus" type="button"  class="btn btn-warning btn-sm left1" onclick="sub();">-</button>
   <input type="text" class="input-group-text" name="value" id="value" value="0">
 <button id="plus" type="button" class="btn btn-info btn-sm right1" onclick="add();">+</span>
 </div>
 </div>
</div>