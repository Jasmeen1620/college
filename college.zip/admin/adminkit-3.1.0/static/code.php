 <h1 class="h3 ">Registered Users
                                          <a href="signup.php"><button type="submit" class=" btn btn-lg btn-primary mb-3 float-end " name="checkEmail">Add New User</button></a>


					<div class="row">
						<div class="col-15">
								<div class="card-body">
									<table class="table table-bodered " style="height:100px;">
										<thead>
											<tr>
                                                <th>srNo</th>
												<th>ID</th>
												<th>First Name</th>
												<th>Last Name</th>
												<th>Email Id</th>
												<th>Username</th>
												<th>Status</th>
												<th>Edit</th>
												<th>Delete</th>
											</tr>
										</thead>
										
										<?php
                                        $j=1;
                                        $start=0;
										if($records)
										{
											foreach($records as $row)
											{
												
										?>

											<tr id="user_info_<?= $row['id'] ?>">
                                                <td><?php echo $j+$start; ?></td>
												<td><?php echo $row['id'];?></td>
												<td><?php echo  $row['firstname'];?></td>
												<td><?php echo  $row['lastname'];?></td>
												<td><?php echo  $row['emailid'];?></td>
												<td><?php echo  $row['username'];?></td>
                                                
												<td>
													<?php
													$status=$row['status'];
													if ($status == 1){
														?>
														<a class="btn btn-success btn1"  href="users.php?status=0&id=<?= $row['id'] ?>" >Active</button>

														<?php
													}
													else{
														?>
														<a class="btn btn-danger btn1" href="users.php?status=1&id=<?= $row['id'] ?>">Inactive</button>
														<?php
													}
													?>
												<td><button type="button" class="btn btn-primary editbtn" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" >Edit</button></td>	

												<td><button type="button" class="btn btn-danger deletebtn" data-attr="<?= $row['id'] ?>" data-bs-target="deletemodal" data-bs-whatever="@mdo">Delete</button></td>
											</tr>
											<?php
									  $j++; }
								}
								else {
									echo "no record found";
								}
   								?>
   							</table>















   							   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#records-limit').change(function () {
                $('#form1').submit();
            });

            $(document).on('click','.deletebtn',function (){
                value = $(this).data('attr');
                if (confirm('Are you sure want to delete the data?')){
                    $.ajax({
                        url: 'delete_record.php',
                        method: 'POST',
                        data: 'id='+value+'&name=test',
                        success: function(response) {
                            alert(response);
                            $('#user_info_'+value).remove();
                        },error: function (e){
                            alert(e.statusText);
                        }
                    })
                }    
            })
           
        });
    </script>
	
									<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="height:80%">
    <div class="modal-dialog row justify-content-center" role="document" align="center" style="height:100%">

        <div class="modal-content" align="left" style="height:100%">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> Edit Student Data </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" name="editbtn"></button>
            </div>
            <div class="mb-2">
            </div>
            <form action="" id="custForm" name="custForm" method="POST" >
            	
                <div class="form-group text-center mb-2 col-9 fw-bold" style="margin-left:3%">
                  <label >ID</label>
                  <input type="text" class="form-control "   value="" name="id" id="id" required>
                </div>
              
                <div class="form-group text-center mb-2 col-9 fw-bold"style="margin-left:3%">
                  <label >first Name</label>
                  <input type="text" class="form-control " placeholder="firstname" id="firstname" name="firstname" required>
                </div>
                <div class="form-group text-center mb-2 col-9 fw-bold"style="margin-left:3%">
                  <label >Last Name</label>
                  <input type="text" class="form-control " placeholder="lastname" value="" id="lastname" name="lastname" required>
                </div>
               
                <div class="form-group text-center md-2 col-9 fw-bold"style="margin-left:3%">
                  <label >Email-Id</label>
                  <input type="text" class="form-control " placeholder="emailid" id="emailid" value="" name="emailid" required>
                </div>
                 <div class="form-group text-center mb-3 col-9 fw-bold"style="margin-left:3%">
                  <label>Username</label>
                  <input type="text" class="form-control " placeholder="username" value="" id="username" name="username" required>
                </div>
                <div class="form-group mb-5 col-9 fw-bold"style="margin-left:3%">
                  
                    <button type="submit" id="submit" value="create" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- DELETE POP UP FORM (Bootstrap MODAL) -->
        <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"> Delete Student Data 
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

                        </button>
                    </div>
                    <form action="deletecode1.php" method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="delete_id" id="delete_id">
                            <h4> Do you want to Delete this Data ??</h4>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"> NO 
                            </button>
                            <button type="submit" name="deletedata" class="btn btn-primary"> Yes !! Delete it. 
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
				
<script>
    $(document).ready(function () {
        $('.editbtn').on('click', function () {
            $('#editmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();
                console.log(data);
                $('#id').val(data[1]);
                $('#firstname').val(data[2]);
                $('#lastname').val(data[3]);
                $('#emailid').val(data[4]);
                $('#username').val(data[5]);
            });
        $('#custForm').submit(function() {
         
        // ajax
        $.ajax({
            type:"POST",
            url: "update.php",
            data: $(this).serialize(), // get all form field value in 
            dataType: 'json',
            success: function(res){
             alert(response);
           }
        });

    });
        });
</script>