<!DOCTYPE html>
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script>
  $(document).ready(function(){
    $('.left').click(function(){
    var qty_val = $(this).next().val();
    if(qty_val>0){
    $('#value').val(parseInt(qty_val)-1);                   
    }
    });
    $('.right').click(function(){
    if($('#value').val()!="10"){
    var qty_val1 = $(this).prev().val();
    $('#value').val(parseInt(qty_val)+1);
    }
    });   
  });
  </script>
</head>

<body>

<div class="container">
    <div class="row">
 <div class="col-lg-12">
 <label for="qty">Quntity:</label>
 </div>
 </div>
 <div class="row">
 <div class="col-lg-12">
 <span class="btn btn-danger btn-sm left">-</span>
   <input type="text" class="value" name="value" id="value" value="0">
 <span class="btn btn-primary btn-sm right">+</span>
 </div>
 </div>
</div>
</body>
</html>