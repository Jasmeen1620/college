<?php
require_once 'submit.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<title>Blank Page | AdminKit Demo</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.php">
          <span class="align-middle">Admin</span>
        </a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Pages
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="index.php">
              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="pages-profile.html">
              <i class="align-middle" data-feather="user"></i> <span class="align-middle">Profile</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="fee.php">
              <i class="align-middle" data-feather="book-open"></i> <span class="align-middle">FEE Structure</span>
            </a>
					</li>

					<li class="sidebar-item active">
						<a class="sidebar-link" href="users.php">
              <i class="align-middle" data-feather="book"></i> <span class="align-middle">Registered Users/Students</span>
            </a>
					</li>
					
				</ul>

				
			</div>
		</nav>

		<div class="main">
			<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle js-sidebar-toggle">
          <i class="hamburger align-self-center"></i>
        </a>

				<div class="navbar-collapse collapse">
					<ul class="navbar-nav navbar-align">
						<li class="nav-item dropdown">
							
							<div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="alertsDropdown">
								<div class="dropdown-menu-header">
									4 New Notifications
								</div>
								<div class="list-group">
									
									
										<div class="row g-0 align-items-center">
											
										</div>
									
								
										<div class="row g-0 align-items-center">
											
										</div>
									
									
										<div class="row g-0 align-items-center">
											
										</div>
									
								</div>
								
							</div>
						</li>
						<li class="nav-item dropdown">
							
							<div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="messagesDropdown">
								
								<div class="list-group">

										<div class="row g-0 align-items-center">
											
										</div>

									
										<div class="row g-0 align-items-center">
											
										</div>
									
										<div class="row g-0 align-items-center">
											
										</div>
									
									
										<div class="row g-0 align-items-center">
											
										</div>
							
								</div>
								
							</div>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
                <i class="align-middle" data-feather="settings"></i>
              </a>

							<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
               
              </a>
							<div class="dropdown-menu dropdown-menu-end">
								<a class="dropdown-item" href="pages-profile.html"><i class="align-middle me-1" data-feather="user"></i> Profile</a>
								
								<div class="dropdown-divider"></div>
								
								
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="#">Log out</a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-4 text-center mb-0">
					<h2 class="heading-section"></h2>
				</div>
			</div>
			<div class="w-100">
			<div class="row justify-content-center">
				<div class="col-md-20 col-lg-5">
					<div class="wrap d-md-flex">
						<div class="img" style="background-image: url(images/bg-2.jpg);">
			      </div>
			    </div>
						
			      <div class="card w-100 " style="margin-top:5%">
                  	<div class="card-header">
			      			<h3 class="mb-4">Add User</h3>
			      		</div>
							<div class="container">
 
							<form method="post" class="signin-form" action="">
								<div class="row" style="margin-top:5%">
			      		<div class="form-group mb-4 col ">
			      			<label class="label" for="name">First Name</label>
			      			<input type="text" class="form-control" placeholder="firstname"  value="<?= $firstname ?>" name="firstname" required>
			      		</div>
			      		<div class="form-group mb-4 col">
			      			<label class="label" for="name">Last Name</label>
			      			<input type="text" class="form-control" placeholder="lastname" value="<?= $lastname ?>"  name="lastname" required>
			      		</div>
			      	</div>
			      	<div class="row">
			      		<div class="form-group mb-4 col">
			      			<label class="label" for="name">Email-Id</label>
			      			<input type="text" class="form-control" placeholder="emailid" value="<?= $emailid ?>"   name="emailid" required>
			      			<?php 
			      				if(isset($errors['emailid'])){
			      			?>
			      				<span class="text-danger"><?= $errors['emailid'] ?></span>
			      			<?php		
			      				}
			      			?>	
			      		</div>
			      		 <div class="form-group mb-4 col">
		            	<label class="label" for="contact">Contact/Phone</label>
		              <input type="text" class="form-control" placeholder="contact" value="<?= $contact ?>"  name="contact" required>
		            </div>
		        </div>
			      		 <div class="form-group mb-4 col-12">
		            	<label class="label" for="password">Username</label>
		              <input type="text" class="form-control" placeholder="username" value="<?= $username ?>"  name="username" required>
		            </div>
		            <div class="row">
		            <div class="form-group mb-4 col">
		            	<label class="label" for="password">Password</label>
		              <input type="password" class="form-control" placeholder="Password" name="password" required>
		            </div>
		             <div class="form-group mb-4 col">
		            	<label class="label" for="password">Confirm Password</label>
		              <input type="password" class="form-control" placeholder="Password" name="confirmpassword" required>
		            </div>
		        </div>
		            <div class="form-group  mb-4 ">
		            	<button type="submit" class="form-control btn btn-primary rounded submit px-3" name="checkEmail">Sign Up</button>
		            </div>
		            <div class="form-group d-md-flex">
		            
		            </div>
		          </form>
		         </div>
		      </div>
				</div>
			</div>
		</div>
	</section>
	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>