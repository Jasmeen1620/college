<?php
require_once 'connection.php';
$ID = $_POST['ID'] ?? 0;
$db = new Db();
$query = 'delete from fees where ID='.$ID;
$records = $db->query($query);
echo 'Your record has been deleted successfully';
exit;
?>