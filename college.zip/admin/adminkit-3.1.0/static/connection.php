<?php
Class Db {
	public $db;

	public function __construct() // magic functions
	{
		$host = 'localhost';
		$user = 'root';
		$password = '';
		$db_name = 'college';
		$this->db = mysqli_connect($host,$user,$password,$db_name) or die(mysqli_connect_error);
	}

	public function query($sql){
		if ($result = mysqli_query($this->db, $sql)) {
			if(is_object($result)){
				return mysqli_fetch_all($result,MYSQLI_ASSOC);	
			}
			return $result;
		}
		return false;
	}
}
