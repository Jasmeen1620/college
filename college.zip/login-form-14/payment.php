<?php
require_once 'connection.php';
session_start();
$db = new Db();
$query = 'SELECT * from fees';
$records = $db->query($query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>User page</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

	<style>

		body {
  overflow-x: hidden;
}

#wrapper {
  padding-left: 0;
  -webkit-transition: all 0.5s ease;
  -moz-transition: all 0.5s ease;
  -o-transition: all 0.5s ease;
  transition: all 0.5s ease;
}

#wrapper.toggled {
  padding-left: 250px;
}

#sidebar-wrapper {
  z-index: 1000;
  position: fixed;
  left: 250px;
  width: 0;
  height: 100%;
  margin-left: -250px;
  overflow-y: auto;
  background: #000;
  -webkit-transition: all 0.5s ease;
  -moz-transition: all 0.5s ease;
  -o-transition: all 0.5s ease;
  transition: all 0.5s ease;
}

#wrapper.toggled #sidebar-wrapper {
  width: 250px;
}

#page-content-wrapper {
  width: 100%;
  position: absolute;
  padding: 15px;
}

#wrapper.toggled #page-content-wrapper {
  position: absolute;
  margin-right: -250px;
}


/* Sidebar Styles */

.sidebar-nav {
  position: absolute;
  top: 0;
  width: 250px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.sidebar-nav li {
  text-indent: 20px;
  line-height: 40px;
}

.sidebar-nav li a {
  display: block;
  text-decoration: none;
  color: #999999;
}

.sidebar-nav li a:hover {
  text-decoration: none;
  color: #fff;
  background: rgba(255, 255, 255, 0.2);
}

.sidebar-nav li a:active, .sidebar-nav li a:focus {
  text-decoration: none;
}

.sidebar-nav>.sidebar-brand {
  height: 65px;
  font-size: 18px;
  line-height: 60px;
}

.sidebar-nav>.sidebar-brand a {
  color: #999999;
}

.sidebar-nav>.sidebar-brand a:hover {
  color: #fff;
  background: none;
}

@media(min-width:768px) {
  #wrapper {
    padding-left: 0;
  }
  #wrapper.toggled {
    padding-left: 250px;
  }
  #sidebar-wrapper {
    width: 0;
  }
  #wrapper.toggled #sidebar-wrapper {
    width: 250px;
  }
  #page-content-wrapper {
    padding: 20px;
    position: relative;
  }
  #wrapper.toggled #page-content-wrapper {
    position: relative;
    margin-right: 0;
  }
}
.mode {
            float:right;
        }
        .change {
            cursor: pointer;
            border: 1px solid #555;
            border-radius: 40%;
            width: 20px;
            text-align: center;
            padding: 5px;
            margin-left: 8px;
        }
        .dark{
            background-color: #222;
            color: white;
        }
.loader-container{
            width: 100%;
            height: 100vh;
            background-color: black;
            position: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader{
            width: 50px;
            height: 50px;
            border: 5px solid;
            color: #3498db;
            border-radius: 50%;
            border-top-color: transparent;
            animation: loader 1.2s linear infinite;
        }
        @keyframes loader{
            25%{
                color: #2ecc71;
            }
            50%{
                color: #f1c40f;
            }
            75%{
                color: #e74c3c;
            }
            to{
                transform: rotate(360deg);
            }
        }
	</style>
</head>
<body>
  <div class="loader-container">
        <div class="loader"></div>
    </div>
    <div id="wrapper" class="toggled">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Student Panel
                    </a>
                </li>
                <li>
                    <a href="home1.php">Home</a>
                </li>
                <li>
                    <a href="payment.php">Payment</a>
                </li>
                <li>
                    <a href="profile.php">My Account</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
                <li>
                   
            </ul>
        </div>
         <div id="page-content-wrapper">
            <div class="container-fluid">
              <div class="mb-3">
                    <div class="card-header" style="margin-top:2%">
            <h1 class="h3 d-inline align-middle" >Fee Structure</h1>
                   
                </div></h1>


                    <div class="card-body">
                  <table class="table table-bodered" style="width:100% " cellspacing="100px">
                    <thead>
                      
                      <tr>
                        <th style="padding:5px">No.</th>
                        <th>Courses</th>
                        <th>FEES</th>
                        <th>Payment</th>
                      </tr>
                        <?php
                    if($records)
                    {
                      foreach($records as $row)
                      {
                        
                    ?>
                      <tr>
                        <td style="padding:5px"><?php echo $row['ID'];?></td>
                      
                        <td><?php echo  $row['courses'];?></td>
                        <td><?php echo $row['fees'];?></td>
                        <td><button type="button" class="btn btn-primary editbtn" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">PAY</button></td>
                      </tr>
                      
                                <?php
                  }
                }
                else {
                  echo "no record found";
                }
                ?>
                      



        </div>
      </main>
  </div>
  </div>
          <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ">
        <h5 class="modal-title " id="exampleModalLabel" style="margin-left:40%">PAYMENT</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
         <form action="updatecode1.php"  method="POST" >
               <div class="modal-body"  style="width: 75%;text-align: center;" ></div>
               
                <div class="row">
                <div class="form-group mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label style="margin-left:42%">COURSE</label>
                  <input type="text" class="form-control text-center"  name="courses" id="courses"  required>
                </div></div>
                <div class="row">
                   <div class="form-group mb-4 col-9 fw-bold" style="margin-left:10%">
                  <label style="margin-left:30%">SELECT SEMESTER</label>
                <div class="dropdown mb-2" style="text-align:center">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"style="text-align:center;">
    select semester
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" href="#">1st</a></li>
    <li><a class="dropdown-item" href="#">2nd</a></li>
    <li><a class="dropdown-item" href="#">3rd</a></li>
  </ul>
</div>
</div>
 </div>           
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         <button type="submit" name="updatedata" class="btn btn-primary">Update</button>
      </div>
            </form>
      </div>
      
    </div>
  </div>
</div>

<script>
    $(document).ready(function () {
        $('.editbtn').on('click', function () {
            $('#exampleModal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();
                console.log(data);
                $('#ID').val(data[0]);
                $('#courses').val(data[1]);
                $('#fees').val(data[2]);
               
            });
        });
</script>
</body>

</html>   
<script>
        $(window).on("load",function(){ 
            $(".loader-container").fadeOut(500);
        });
    </script>
       