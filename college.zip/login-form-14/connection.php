<?php
Class Db {
	public $db;

	public function __construct() // magic functions
	{
		$host = 'localhost';
		$user = 'root';
		$password = '';
		$db_name = 'college';
		$this->db = mysqli_connect($host,$user,$password,$db_name) or die(mysqli_connect_error);
	}

	public function query($sql,$isOneRecord=0){
		if ($result = mysqli_query($this->db, $sql)) {
			if(is_object($result)){
				if($isOneRecord){
					return mysqli_fetch_assoc($result);
				}
				return mysqli_fetch_all($result,MYSQLI_ASSOC);	
			}
			return $result;
		}
		return false;
	}
}