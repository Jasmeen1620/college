<?php
require_once 'connection.php';
session_start();
$id = $_SESSION['id'] ?? 0;
$db = new Db();
$query = 'SELECT * from student where id='.$id;
$row = $db->query($query,1);

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>User page</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	<style>

		body {
  overflow-x: hidden;
}

#wrapper {
  padding-left: 0;
  -webkit-transition: all 0.5s ease;
  -moz-transition: all 0.5s ease;
  -o-transition: all 0.5s ease;
  transition: all 0.5s ease;
}

#wrapper.toggled {
  padding-left: 250px;
}

#sidebar-wrapper {
  z-index: 1000;
  position: fixed;
  left: 250px;
  width: 0;
  height: 100%;
  margin-left: -250px;
  overflow-y: auto;
  background: #000;
  -webkit-transition: all 0.5s ease;
  -moz-transition: all 0.5s ease;
  -o-transition: all 0.5s ease;
  transition: all 0.5s ease;
}

#wrapper.toggled #sidebar-wrapper {
  width: 250px;
}

#page-content-wrapper {
  width: 100%;
  position: absolute;
  padding: 15px;
}

#wrapper.toggled #page-content-wrapper {
  position: absolute;
  margin-right: -250px;
}


/* Sidebar Styles */

.sidebar-nav {
  position: absolute;
  top: 0;
  width: 250px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.sidebar-nav li {
  text-indent: 20px;
  line-height: 40px;
}

.sidebar-nav li a {
  display: block;
  text-decoration: none;
  color: #999999;
}

.sidebar-nav li a:hover {
  text-decoration: none;
  color: #fff;
  background: rgba(255, 255, 255, 0.2);
}

.sidebar-nav li a:active, .sidebar-nav li a:focus {
  text-decoration: none;
}

.sidebar-nav>.sidebar-brand {
  height: 65px;
  font-size: 18px;
  line-height: 60px;
}

.sidebar-nav>.sidebar-brand a {
  color: #999999;
}

.sidebar-nav>.sidebar-brand a:hover {
  color: #fff;
  background: none;
}

@media(min-width:768px) {
  #wrapper {
    padding-left: 0;
  }
  #wrapper.toggled {
    padding-left: 250px;
  }
  #sidebar-wrapper {
    width: 0;
  }
  #wrapper.toggled #sidebar-wrapper {
    width: 250px;
  }
  #page-content-wrapper {
    padding: 20px;
    position: relative;
  }
  #wrapper.toggled #page-content-wrapper {
    position: relative;
    margin-right: 0;
  }
}
  .modal-dialog {
 
          width: 400px;
 
          height:950px !important;
 
        }
        .modal-content {
 
    /* 80% of window height */
 
    height: 60%;
 
    background-color:#BBD6EC;
 
}       
 
.modal-header {
 
    background-color: #337AB7;
 
    padding:16px 16px;
 
    color:#FFF;
 
    border-bottom:2px dashed #337AB7;
 
 }
article {
  background: linear-gradient(
    to right, 
    hsl(98 100% 62%), 
    hsl(204 100% 59%)
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-align: center;
}

h1 {
  font-size: 10vmin;
  line-height: 1.1;
}


h1, p, body {
  margin: 0;
}

p {
  font-family: "Dank Mono", ui-monospace, monospace;
}

html {
  block-size: 100%;
  inline-size: 100%;
}
.content {
  padding: 16px;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 60px;
}
.navbar-default{
  transition:500ms ease;
  background:transparent;
}
.navbar-default.scrolled{
  background:#000;
}
.mode {
            float:right;
        }
        .change {
            cursor: pointer;
            border: 1px solid #555;
            border-radius: 40%;
            width: 20px;
            text-align: center;
            padding: 5px;
            margin-left: 8px;
        }
        .dark{
            background-color: #222;
            color: white;
        }
.loader-container{
            width: 100%;
            height: 100vh;
            background-color: black;
            position: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader{
            width: 50px;
            height: 50px;
            border: 5px solid;
            color: #3498db;
            border-radius: 50%;
            border-top-color: transparent;
            animation: loader 1.2s linear infinite;
        }
        @keyframes loader{
            25%{
                color: #2ecc71;
            }
            50%{
                color: #f1c40f;
            }
            75%{
                color: #e74c3c;
            }
            to{
                transform: rotate(360deg);
            }
        }
	</style>
</head>
<body>
  <div class="loader-container">
        <div class="loader"></div>
    </div>
    <div id="wrapper" class="toggled">

        <!-- Sidebar -->

        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Start Bootstrap
                    </a>
                </li>
                <li>
                    <a href="home1.php">Home</a>
                </li>
                <li>
                    <a href="payment.php">Payment</a>
                </li>
                <li class="sidebar-item active">
                    <a href="profile.php">My Account</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
                <li>
                   
            </ul>
        </div>
       <div class="main">
       <div id="navbar">
      <nav class="navbar navbar-expand navbar-light navbar-bg  navbar-fixed-top">
        <a class="sidebar-toggle js-sidebar-toggle">
          <i class="hamburger align-self-center"></i>
        </a>
         <div class="mode float-end">
        Dark mode:            
        <span class="change">OFF</span>
    </div>
      </nav>
    </div>
         <div id="page-content-wrapper">
            <div class="container-fluid">
<div class="col-md-6" style="margin-left:25%">
  <article>
<h1 ><?php
  echo "Welcome ".$_SESSION['user_name'];
?></h1>
</article>
</div>
<div class="container row mx-md-n5" style="margin-top:5%" "margin-left:50%">
                          <div class="col-3 px-5 md-2"><div class="p-3 border bg-info" style="--bs-bg-opacity: .5;">ID</div>
                        <div class="p-3 border bg-info"style="--bs-bg-opacity: .2;">First Name</div>
                        <div class="p-3 border bg-info"style="--bs-bg-opacity: .2;">Last Name</div>
                      <div class="p-3 border bg-info"style="--bs-bg-opacity: .5;">Email Id</div>
                    <div class="p-3 border bg-info"style="--bs-bg-opacity: .2;">Contact</div>
                  <div class="p-3 border bg-info"style="--bs-bg-opacity: .5;">Username</div></div>
                  <tr>
                   <div id="div1" class="col-6 px-md-1 div1">
                       <td><div class="p-3 border bg-info td"style="--bs-bg-opacity: .1;"><?php echo  $row['id'];?></div></td>
                       <td><div class="p-3 border bg-info td"style="--bs-bg-opacity: .1;"><?php echo  $row['firstname'];?></div></td>
                       <td><div class="p-3 border bg-info td"style="--bs-bg-opacity: .1;"><?php echo  $row['lastname'];?></div></td>
                       <td><div class="p-3 border bg-info td"style="--bs-bg-opacity: .1;"><?php echo  $row['emailid'];?></div></td>
                       <td><div  class="p-3 border bg-info td"style="--bs-bg-opacity: .1;"><?php echo  $row['contact'];?></div></td>
                       <td><div  class="p-3 border bg-info td"style="--bs-bg-opacity: .1;"><?php echo  $row['username'];?></div></td>
                  </div> 
                
                  <div class ="container px-5 md-2"style="margin-top:3%">
                      <td>  <button type="button" class="btn btn-primary editbtn" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" >update</button></td></div></tr>   
              </div>
            </div>
          
        <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

  
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="height:80%">
    <div class="modal-dialog row justify-content-center" role="document" align="center" style="height:100%">

        <div class="modal-content" align="left" style="height:100%">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> Edit Student Data </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" name="editbtn"></button>
            </div>
            <div class="mb-2">
            </div>
            <form action="" id="custForm" name="custForm" method="POST" >
              
                <div class="form-group text-center mb-2 col-9 fw-bold" style="margin-left:3%">
                  <label >ID</label>
                  <input type="text" class="form-control "   value="" name="id" id="id" required>
                </div>
              
                <div class="form-group text-center mb-2 col-9 fw-bold"style="margin-left:3%">
                  <label >first Name</label>
                  <input type="text" class="form-control " placeholder="firstname" id="firstname" name="firstname" required>
                </div>
                <div class="form-group text-center mb-2 col-9 fw-bold"style="margin-left:3%">
                  <label >Last Name</label>
                  <input type="text" class="form-control " placeholder="lastname" value="" id="lastname" name="lastname" required>
                </div>
                <div class="form-group text-center md-2 col-9 fw-bold"style="margin-left:3%">
                  <label >Email-Id</label>
                  <input type="text" class="form-control " placeholder="emailid" id="emailid" value="" name="emailid" required>
                </div>
                <div class="form-group text-center md-2 col-9 fw-bold"style="margin-left:3%">
                  <label >Contact</label>
                  <input type="text" class="form-control " placeholder="contact" id="contact" value="" name="contact" required>
                </div>
                 <div class="form-group text-center mb-3 col-9 fw-bold"style="margin-left:3%">
                  <label>Username</label>
                  <input type="text" class="form-control " placeholder="username" value="" id="username" name="username" required>
                </div>
                <div class="form-group mb-5 col-9 fw-bold"style="margin-left:3%">
                  
                    <button type="submit" id="submit" value="create" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
<script>
    $(document).ready(function () {
        $('.editbtn').on('click', function () {
            $('#exampleModal').modal('show');
          $tr = $(this).closest('#div1');
            var data = $tr.children(".td").map(function () {
                return $(this).text();
            }).get();
                console.log(data);
                $('#id').val(data[0]);
                $('#firstname').val(data[1]);
                $('#lastname').val(data[2]);
                $('#emailid').val(data[3]);
                 $('#contact').val(data[4]);
                $('#username').val(data[5]);
            });
        $('#custForm').submit(function() {
         
        // ajax
        $.ajax({
            type:"POST",
            url: "edit.php",
            data: $(this).serialize(), // get all form field value in 
            dataType: 'json',
            success: function(res){
             alert(response);
           }
        });

    });
        });
</script>

  <script>
window.onscroll = function() {myFunction()};
var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script> 

 <script>
        $( ".change" ).on("click", function() {
            if( $( ".main" ).hasClass( "dark" )) {
                $( ".main" ).removeClass( "dark" );
                $( ".change" ).text( "OFF" );
                 $( ".h3" ).css( "color","black" );
                 $( "td,th" ).css( "color","black" );
               
            } else {
                $( ".main" ).addClass( "dark" );
                 $( ".h3" ).css( "color","white" );
                 $( "td,th" ).css( "color","white" );
                $( ".change" ).text( "ON" );
              
            }
        });
    </script>
    
</html>
<script>
        $(window).on("load",function(){ 
            $(".loader-container").fadeOut(500);
        });
    </script>