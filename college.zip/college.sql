-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 06, 2022 at 07:28 AM
-- Server version: 8.0.27
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'jasmeen1@gmail.com', 'jasmeen'),
(5, 'jasmeen1@gmail.com', 'jasmeen');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
CREATE TABLE IF NOT EXISTS `fees` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `courses` varchar(100) NOT NULL,
  `fees` int NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`ID`, `courses`, `fees`, `createdDate`, `modifiedDate`) VALUES
(1, 'MCA', 200000, '2022-08-08 10:16:37', '2022-08-17 09:48:37'),
(2, 'MBA', 200000, '0000-00-00 00:00:00', '2022-08-16 10:03:08'),
(3, 'BCA', 150000, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'MscIT', 150000, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'BBA', 200000, '0000-00-00 00:00:00', '2022-08-09 12:58:56'),
(6, 'Mcom', 200000, '2022-08-09 13:10:08', '0000-00-00 00:00:00'),
(7, 'BA', 150000, '2022-08-12 15:43:08', '0000-00-00 00:00:00'),
(8, 'MA', 200000, '2022-08-12 15:44:00', '0000-00-00 00:00:00'),
(9, 'B.Tech', 150000, '2022-08-12 15:44:27', '0000-00-00 00:00:00'),
(10, 'Bcom', 150000, '2022-08-12 15:45:03', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mysql_table_search`
--

DROP TABLE IF EXISTS `mysql_table_search`;
CREATE TABLE IF NOT EXISTS `mysql_table_search` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `full_name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `mysql_table_search`
--

INSERT INTO `mysql_table_search` (`id`, `from_date`, `to_date`, `full_name`, `email`, `city`) VALUES
(1, '2020-11-28', '2020-12-04', 'Logan Brown', 'loganbrown@gmail.com', 'Portsmouth'),
(2, '2020-10-25', '2020-10-28', 'Noah Davies', 'noahdavies@gmail.com', 'Southampton'),
(3, '2020-08-18', '2020-08-24', 'Mason Wilson', 'masonwilson@gmail.com', 'London'),
(4, '2020-09-17', '2020-09-23', 'Liam Jones', 'liamjones@gmail.com', 'Sheffield'),
(5, '2020-07-12', '2020-07-16', 'Amelia Jones', 'ameliajones@gmail.com', 'London'),
(6, '2020-12-03', '2020-12-09', 'Emma Jackson', 'emmajackson@gmail.com', 'Birmingham'),
(7, '2020-08-03', '2020-08-07', 'William Johnson', 'williamjohnson@gmail.com', 'Leeds'),
(8, '2020-10-21', '2020-10-26', 'Elijah  Jones', 'elijahjones@gmail.com', 'Nottingham'),
(9, '2020-10-15', '2020-10-18', 'Logan Brown', 'loganbrown@gmail.com', 'Manchester'),
(10, '2020-07-28', '2020-07-31', 'Olivia Hall', 'oliviahall@gmail.com', 'London'),
(11, '2020-11-14', '2020-11-21', 'Benjamin Clarke', 'benjaminclarke@gmail.com', 'Leeds'),
(12, '2020-11-03', '2020-11-08', 'Amelia Roberts', 'ameliaroberts@gmail.com', 'Nottingham'),
(13, '2020-11-03', '2020-11-10', 'Emma Brown', 'emmabrown@gmail.com', 'Newcastle'),
(14, '2020-10-15', '2020-10-22', 'Olivia Robinson', 'oliviarobinson@gmail.com', 'Southampton'),
(15, '2020-12-09', '2020-12-12', 'Harper Jones', 'harperjones@gmail.com', 'Leeds'),
(16, '2020-10-05', '2020-10-11', 'Liam Jackson', 'liamjackson@gmail.com', 'Manchester'),
(17, '2020-10-03', '2020-10-07', 'Olivia Evans', 'oliviaevans@gmail.com', 'Leeds'),
(18, '2020-10-19', '2020-10-24', 'Noah Taylor', 'noahtaylor@gmail.com', 'Nottingham'),
(19, '2020-10-27', '2020-10-31', 'Benjamin Green', 'benjamingreen@gmail.com', 'Nottingham'),
(20, '2020-08-14', '2020-08-19', 'Mia Walker', 'miawalker@gmail.com', 'Newcastle'),
(21, '2020-08-27', '2020-09-02', 'Oliver Jackson', 'oliverjackson@gmail.com', 'Portsmouth'),
(22, '2020-08-21', '2020-08-26', 'William Roberts', 'williamroberts@gmail.com', 'Birmingham'),
(23, '2020-08-25', '2020-08-31', 'Liam Green', 'liamgreen@gmail.com', 'Nottingham'),
(24, '2020-10-28', '2020-11-03', 'Isabella Smith', 'isabellasmith@gmail.com', 'Manchester'),
(25, '2020-08-29', '2020-09-05', 'Emma Thompson', 'emmathompson@gmail.com', 'Southampton'),
(26, '2020-07-30', '2020-08-05', 'Sophia Robinson', 'sophiarobinson@gmail.com', 'Newcastle'),
(27, '2020-09-01', '2020-09-04', 'Elijah  White', 'elijahwhite@gmail.com', 'Manchester'),
(28, '2020-06-23', '2020-06-29', 'James Roberts', 'jamesroberts@gmail.com', 'Newcastle'),
(29, '2020-06-26', '2020-06-29', 'Emma Wright', 'emmawright@gmail.com', 'Southampton'),
(30, '2020-08-23', '2020-08-30', 'Liam Walker', 'liamwalker@gmail.com', 'Sheffield'),
(31, '2020-10-17', '2020-10-22', 'Ava Evans', 'avaevans@gmail.com', 'Liverpool'),
(32, '2020-07-25', '2020-07-31', 'Emma Hall', 'emmahall@gmail.com', 'London'),
(33, '2020-09-19', '2020-09-24', 'Liam Williams', 'liamwilliams@gmail.com', 'Liverpool'),
(34, '2020-07-16', '2020-07-21', 'Lucas Smith', 'lucassmith@gmail.com', 'London'),
(35, '2020-09-22', '2020-09-27', 'Mason Hall', 'masonhall@gmail.com', 'Liverpool'),
(36, '2020-08-17', '2020-08-22', 'Mia Robinson', 'miarobinson@gmail.com', 'Birmingham'),
(37, '2020-08-16', '2020-08-20', 'Logan Taylor', 'logantaylor@gmail.com', 'Birmingham'),
(38, '2020-06-21', '2020-06-28', 'Elijah  Smith', 'elijahsmith@gmail.com', 'Nottingham'),
(39, '2020-10-25', '2020-10-27', 'Harper Thompson', 'harperthompson@gmail.com', 'Southampton'),
(40, '2020-10-26', '2020-11-01', 'James Brown', 'jamesbrown@gmail.com', 'Birmingham'),
(41, '2020-12-05', '2020-12-11', 'Logan Thompson', 'loganthompson@gmail.com', 'Sheffield'),
(42, '2020-10-24', '2020-10-29', 'Amelia Walker', 'ameliawalker@gmail.com', 'Newcastle'),
(43, '2020-07-26', '2020-07-29', 'Elijah  Jones', 'elijahjones@gmail.com', 'Birmingham'),
(44, '2020-07-29', '2020-08-01', 'Mia Johnson', 'miajohnson@gmail.com', 'Nottingham'),
(45, '2020-10-31', '2020-11-04', 'William Johnson', 'williamjohnson@gmail.com', 'London'),
(46, '2020-06-24', '2020-06-28', 'Noah Wilson', 'noahwilson@gmail.com', 'Manchester'),
(47, '2020-11-24', '2020-11-30', 'Sophia Wood', 'sophiawood@gmail.com', 'Leeds'),
(48, '2020-10-25', '2020-10-29', 'Harper Johnson', 'harperjohnson@gmail.com', 'Southampton'),
(49, '2020-10-19', '2020-10-21', 'Logan Wright', 'loganwright@gmail.com', 'Portsmouth'),
(50, '2020-07-15', '2020-07-21', 'Elijah  Wilson', 'elijahwilson@gmail.com', 'Liverpool'),
(51, '2020-10-10', '2020-10-13', 'Sophia Williams', 'sophiawilliams@gmail.com', 'London');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lastname` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `emailid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `contact` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `createdDate` datetime NOT NULL,
  `modifiedDate` datetime NOT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `emailid` (`emailid`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `firstname`, `lastname`, `emailid`, `contact`, `username`, `password`, `createdDate`, `modifiedDate`, `status`) VALUES
(24, 'ghjffffsd', 'gfh', 'dffd@', 656354, 'fdddfg', 'gfdg', '2022-08-18 08:26:40', '2022-08-18 08:26:40', NULL),
(5, 'sdxzX', 'szxsad', 'sdaz!@uyj', 453645, 'asxsd', 'sdcsa', '2022-08-18 07:47:41', '2022-08-18 07:47:41', NULL),
(4, 'sdgvfxd', 'dfxcfs', 'fgcgfv', 4532121, 'saty', 'srttttt', '2022-08-18 07:45:54', '2022-08-18 13:18:22', 1),
(3, 'erfs', 'thgfvc', 'erfdsw@rr', 0, 'fdgddf', 'dfgdd', '2022-08-18 07:45:17', '2022-08-18 07:45:17', NULL),
(2, 'fhfstgh', 'ghgfxzc', 'rsthhh@rg', 0, 'tgfrdgter', 'ertsff', '2022-08-18 07:44:52', '2022-08-18 13:18:21', 1),
(17, 'amanpreet', 'kaur', 'amanpreet@gmail.com', 564123313, 'amanpreet06', 'amanpreet06', '2022-08-04 12:19:01', '2022-08-04 12:19:01', 0),
(18, 'ritu', 'sharma', 'ritu@gmail.com', 656984663, 'ritu82', 'ritu82', '2022-08-04 12:19:01', '2022-08-18 12:49:41', 1),
(19, 'jiya', 'verma', 'jiya@gmail.com', 5464522, 'jiya64', 'jiya64', '2022-08-04 12:20:39', '2022-08-19 09:39:53', 0),
(20, 'naveen155', 'kumar', 'naveen@gmail.com', 56465413, 'naveen75', 'naveen75', '2022-08-04 12:20:39', '2022-08-18 15:25:37', 1),
(25, 'asDSS', 'DSAD', 'ff@dddf', 3532, 'tgrgttt', 'tthrt', '2022-08-18 08:27:11', '2022-08-18 08:27:11', NULL),
(26, 'vxfv', 'fvxd', 'fd@fgf', 5555565, 'ftghtr', 'fsffs', '2022-08-18 08:27:44', '2022-08-18 13:58:29', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
